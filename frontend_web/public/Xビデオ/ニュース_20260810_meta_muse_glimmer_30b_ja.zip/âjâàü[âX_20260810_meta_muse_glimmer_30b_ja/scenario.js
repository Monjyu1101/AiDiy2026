window.SCENARIO = {
  "project_name": "ニュース_20260810_meta_muse_glimmer_30b_ja",
  "language": "ja",
  "version": "duo-v2",
  "title": "Meta Muse Glimmer 30B 解説 — ローカル実行向け公開マルチモーダル・エージェントモデル",
  "assets_policy": {
    "male_avatar": "../vrm/VRM_male.vrm",
    "female_avatar": "../vrm/VRM_female.vrm",
    "tts_male": "edge:male",
    "tts_female": "edge:female",
    "audio_output_dir": "frontend_web/public/Xビデオ/ニュース_20260810_meta_muse_glimmer_30b_ja/audio"
  },
  "scenes": [
    {
      "id": "scene_000",
      "title": "イントロ — Muse Glimmer 30B の発表",
      "accent": "#3879c9",
      "accent_soft": "rgba(56, 121, 201, 0.18)",
      "layout": "hero",
      "kicker": "META AI NEWS · 2026.08.10",
      "headline": "Muse Glimmer 30B を読む\nローカル・エージェントへの新しい一手",
      "lead": "Metaが公開した30B級のマルチモーダル・エージェントモデルについて、確認済みの事実と未確認事項を分けて整理します。",
      "image": "images/scene_000.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "Metaは2026年8月10日に、ローカルのエージェントワークフロー向けMuse Glimmerを公開した。",
      "factual_bullets": [
        "2026年8月10日のMeta公式発表",
        "Muse Glimmer 30B",
        "公開ウェイトとApache 2.0ライセンス",
        "ローカル実行を想定したエージェントモデル"
      ],
      "forbidden_elements": [
        "すべての用途で高性能・安全と断定すること",
        "公式資料にない提供条件や実測値を補うこと"
      ],
      "image_prompt": "Editorial AI news illustration, a compact local AI agent running on a personal computer, blue and teal luminous circuitry, two Japanese news presenters implied only as silhouettes, no text, no logos.",
      "dialogue": [
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "このニュース解説動画は AiDiy のニュース版ビデオ生成機能で作られています。",
          "naration_text": "このニュース解説動画は AiDiy のニュース版ビデオ生成機能で作られています。今回は、Metaが2026年8月10日に発表したMuse Glimmer 30Bを取り上げます。公開されたモデルは、手元の機器で動かすローカル・エージェントの利用を意識したものです。まずは公式発表と公式モデルカードで確認できる内容を押さえ、期待できることと、まだ検証が必要なことを混同しないように見ていきましょう。ニュースを楽しく分かりやすくお届けします。",
          "audio": "audio/dlg_000_01_female.mp3",
          "duration_sec": 30.912
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "MetaはMuse Glimmerを、端末上で動く公開エージェントモデルとして紹介しました。",
          "naration_text": "Metaの公式発表によると、Muse Glimmerは30B、つまり約300億パラメータ級のモデルです。常時動作するローカルのエージェントワークフローに最適化したモデルとして紹介され、ローカルのエージェント、関数呼び出し、ローカルでのコーディングなどを想定しています。ここでいう最適化はMetaの説明であり、個々の作業での成果や使いやすさまでを、発表だけで保証する表現ではありません。今日はその入口を丁寧に整理します。",
          "audio": "audio/dlg_000_02_male.mp3",
          "duration_sec": 26.304
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "焦点は、公開ウェイトとローカル実行を組み合わせたエージェント利用の広がりです。注目です。",
          "naration_text": "今回のポイントは、マルチモーダルな理解とエージェント的な処理を、公開ウェイトを使うローカル環境へ近づけようとしている点です。クラウドに依存しない構成は、ネットワーク接続の有無にかかわらず使える可能性や、試作を自分の環境で繰り返せる選択肢につながります。ただし、実際にどこまでローカルで完結できるかは、導入するソフトウェア、ハードウェア、利用する機能によって確認が必要です。その条件は環境によって異なります。",
          "audio": "audio/dlg_000_03_female.mp3",
          "duration_sec": 29.952
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "今日は公開内容、量子化、高速化、活用の見通し、未確認事項の順で整理します。ぜひご覧ください。",
          "naration_text": "この動画では、最初にMuse Glimmer 30Bの位置づけを確認します。続いて、Apache 2.0での公開、約30Bという規模、4bit量子化と24GB級GPU対応を読み解きます。その後、DFlashを使った推論高速化の数値を紹介し、ローカルでの試作やツール連携にどう結び付くかを考えます。最後に、品質、速度、メモリ、安全性、商用利用条件など、公式資料だけでは判断できない点も明確にします。前提条件も確認します。",
          "audio": "audio/dlg_000_04_male.mp3",
          "duration_sec": 32.328
        }
      ],
      "duration_sec": 119.496
    },
    {
      "id": "scene_001",
      "title": "位置づけ — マルチモーダル・エージェントモデル",
      "accent": "#4f8dd8",
      "accent_soft": "rgba(79, 141, 216, 0.18)",
      "kicker": "MODEL POSITIONING",
      "headline": "テキストと画像を扱い\nエージェント作業を支える設計",
      "lead": "公式資料が示す入力形式と、エージェント向けに訓練・評価された能力を確認します。",
      "image": "images/scene_001.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "専用のperception encoderにより、テキストと画像を組み合わせた入力を扱うモデルカード上の説明。",
      "factual_bullets": [
        "入力はテキストと画像、出力はテキスト",
        "マルチステップ推論とツール利用を想定",
        "エージェント的なタスク向けの訓練・評価"
      ],
      "forbidden_elements": [
        "音声入出力が公式に保証されるという表現",
        "あらゆるツール操作を完全自動化できるという表現"
      ],
      "image_prompt": "Multimodal local agent interpreting a screenshot, chart, document, and text prompts on a workstation, clear editorial technology illustration, blue violet palette, no readable text.",
      "dialogue": [
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "Muse Glimmerは、テキストと画像を組み合わせた入力を扱うモデルとして公開されています。",
          "naration_text": "公式モデルカードでは、Muse Glimmer 30Bは専用のperception encoderを備え、テキストと画像を扱うモデルとして説明されています。対応モダリティは入力がテキストと画像、出力がテキストです。つまり、画面のスクリーンショット、図表、文書と会話を一緒に読み取るような用途を想定できる構成です。一方で、音声の入出力までを公式資料が同じように保証しているわけではないため、画像を含む入力の範囲に留めて理解するのが正確です。",
          "audio": "audio/dlg_001_01_female.mp3",
          "duration_sec": 31.488
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "ツール利用、複数段階の推論、失敗からの再試行がエージェント向け能力として挙げられます。",
          "naration_text": "Metaはエージェント向けの能力として、ツール呼び出し、複数段階の推論、失敗からの回復などを挙げています。モデルカードには、予期しないツール結果に対して診断し再試行するよう訓練されたことや、長いワークフローでの計画を維持することが説明されています。これはモデルが目指す性質を示す情報です。実際の業務フローで正しく判断し続けるか、失敗を安全に扱えるかは、接続するツールとガードレールを含むシステム全体で検証する必要があります。",
          "audio": "audio/dlg_001_02_male.mp3",
          "duration_sec": 28.656
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "ローカル実行への意義は、画像を含む作業を自分の環境で試せる選択肢にあります。確認が必要です。",
          "naration_text": "マルチモーダルな理解をローカルで試せるなら、開発中の画面、資料、グラフを含む作業を、手元の環境で試作する選択肢が増えます。これは公開情報から読み取れる将来への見通しです。たとえば、ツール連携の設計を小さなケースで試し、入力と出力を確認しながら改善する流れは考えられます。ただし、画像の種類、文脈の長さ、エージェントの複雑さによって精度と速度は変わり得るので、可能性を実証済みの成果と混同しないことが大切です。",
          "audio": "audio/dlg_001_03_female.mp3",
          "duration_sec": 32.352
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "モデル単体の能力と、実際のエージェントシステムの信頼性は分けて評価します。丁寧に見極めます。",
          "naration_text": "エージェントはモデル単体では完結しません。ツールの権限、入力の検証、実行の記録、失敗時の停止条件、利用者による確認などを組み合わせて初めて運用になります。Metaのモデルカードも、用途と文脈に応じた追加のガードレールを含むシステムとして配備することを推奨しています。Muse Glimmerの公開は選択肢を増やすニュースですが、ローカル実行だけで正確性や安全性が保証される、と受け取らない姿勢が必要です。",
          "audio": "audio/dlg_001_04_male.mp3",
          "duration_sec": 27.264
        }
      ],
      "duration_sec": 119.76
    },
    {
      "id": "scene_002",
      "title": "ローカル実行 — 公開形態と4bit量子化",
      "accent": "#5a73c9",
      "accent_soft": "rgba(90, 115, 201, 0.18)",
      "kicker": "LOCAL DEPLOYMENT",
      "headline": "Apache 2.0と4bit量子化\n24GB級GPUを視野に入れた設計",
      "lead": "公開ライセンスと量子化の事実を、実行環境の条件と分けて確認します。",
      "image": "images/scene_002.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "公開ウェイトはApache 2.0で提供され、K-Quant-17GBは24GB VRAMを対象ハードウェアとして示す。",
      "factual_bullets": [
        "Apache 2.0ライセンス",
        "総パラメータ数は約29.6B",
        "言語モデルは4bit相当で20GB未満",
        "K-Quant-17GBの対象ハードウェアは24GB VRAM"
      ],
      "forbidden_elements": [
        "24GB GPUなら必ず動作するという断定",
        "メモリ容量だけで実用性能を判断する表現"
      ],
      "image_prompt": "Local GPU workstation with a 24GB-class graphics card concept, compact quantized AI model blocks, Apache-style open license document motif without text, blue emerald technical editorial art.",
      "dialogue": [
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "Muse Glimmerの公開ウェイトは、寛容なApache 2.0ライセンスで提供されています。",
          "naration_text": "MetaはMuse Glimmerのモデルウェイトを、Apache 2.0ライセンスでオープンソース化したと発表しています。公式のHugging Faceページにもライセンスはapache-2.0と記載されています。公開ウェイトであることは、開発者が自分の環境で評価や組み込みを検討しやすい条件の一つです。ただし、ライセンスの名称だけで個別の導入可否が決まるわけではありません。配布物の付属文書、依存するソフトウェア、利用する地域や組織のルールを含めて確認する必要があります。",
          "audio": "audio/dlg_002_01_female.mp3",
          "duration_sec": 32.352
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "モデルカードでは総パラメータ数を約29.6Bとし、ローカル利用を前提に設計しています。",
          "naration_text": "モデルカードに記載された総パラメータ数は約29.6Bです。Metaはこのモデルを、消費者向けハードウェアで動く自律的なエージェントタスク向けに設計したと説明しています。30B級のモデルをローカルで扱うには、モデル本体だけでなく、画像理解のためのencoder、会話履歴のKV cache、推論高速化用のdrafterなども考える必要があります。したがって、単純にパラメータ数だけを見て必要な機材や実行のしやすさを判断しないことが重要です。",
          "audio": "audio/dlg_002_02_male.mp3",
          "duration_sec": 28.56
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "公式資料は4bit相当の量子化で言語モデルを20GB未満へ圧縮すると説明します。",
          "naration_text": "公式資料では、モデルの重みをおよそ4bit精度へ量子化し、言語モデル部分を20GB未満に縮小すると説明されています。量子化は、必要なメモリを抑えてローカル実行を現実的にするための技術です。Metaは、画像理解用のperception encoder、KV cache、投機的デコードのdrafterを同時に動かす余地を考慮しているとしています。これは構成上の説明であり、あらゆる入力長、設定、実装で同じメモリ使用量になるという意味ではありません。",
          "audio": "audio/dlg_002_03_female.mp3",
          "duration_sec": 32.664
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "K-Quant-17GBは24GB VRAMを対象にしますが、実際の余裕は条件ごとに確認が必要です。",
          "naration_text": "モデルカードの表では、K-Quant-17GBの対象ハードウェアとして24GB VRAMが示されています。ここから、24GB級GPUでの利用を視野に入れた設計だと読めます。しかし、対象ハードウェアは動作を一律に保証する表ではありません。コンテキスト長、画像入力、バッチサイズ、実装、OS、他の常駐処理によって必要なメモリと速度は変わります。導入時には公式の最新手順を確認し、自分の環境で小さく測定することが確実です。",
          "audio": "audio/dlg_002_04_male.mp3",
          "duration_sec": 31.296
        }
      ],
      "duration_sec": 124.872
    },
    {
      "id": "scene_003",
      "title": "高速推論 — DFlashによる投機的デコード",
      "accent": "#785fc1",
      "accent_soft": "rgba(120, 95, 193, 0.18)",
      "kicker": "DASHED FORWARD",
      "headline": "DFlashで提案し検証する\n生成速度の向上をどう読むか",
      "lead": "RTX 5090での公式測定値と、ベンチマークを一般化しないための注意点を紹介します。",
      "image": "images/scene_003.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "DFlash drafterを使う投機的デコードと、RTX 5090上で74.9 tok/sから233.4 tok/sという公式測定値。",
      "factual_bullets": [
        "DFlashベースの軽量drafter",
        "一度に16トークンのブロックを提案",
        "RTX 5090: 74.9 tok/sから233.4 tok/s",
        "測定はbatch size 1、greedy decoding、多様なプロンプトの平均"
      ],
      "forbidden_elements": [
        "すべてのGPUと用途で3.1倍になる断定",
        "速度向上がタスク品質や安全性を保証するという表現"
      ],
      "image_prompt": "Speculative decoding visualization: a small drafter model proposes token blocks to a larger local AI model that verifies them in parallel, dynamic purple blue data streams, no text or numeric claims.",
      "dialogue": [
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "DFlashは小さなdrafterがトークンのまとまりを提案し、主モデルが並列に検証する方式です。",
          "naration_text": "推論高速化の中心として紹介されているのが、DFlashを基にした軽量なdrafterモデルです。通常の言語モデルはトークンを一つずつ生成しますが、drafterは複数トークンのブロックを先に提案し、主モデルがそれを並列に検証します。モデルカードでは、DFlashのblock-diffusionモデルが一回のforward passで16トークンのブロックを予測すると説明されています。提案と検証を組み合わせることで、逐次生成より速くする狙いです。",
          "audio": "audio/dlg_003_01_female.mp3",
          "duration_sec": 30.384
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "公式表ではRTX 5090で、74.9 tok/sから233.4 tok/sへの向上が示されています。",
          "naration_text": "公式モデルカードの速度表では、Nvidia RTX 5090で、投機的デコードなしの74.9 tok/sに対し、DFlashを使った平均値は233.4 tok/sとされています。表に示されたspeedupは3.1倍です。これは、K-Quant-17GBモデルと量子化されたDFlash drafterを組み合わせた公式の測定値です。数値はローカルの応答性を考えるうえで注目に値しますが、特定の測定条件で得られた平均値として扱う必要があります。",
          "audio": "audio/dlg_003_02_male.mp3",
          "duration_sec": 29.784
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "この数値は、batch size 1とgreedy decodingを使う多様なプロンプトの平均です。",
          "naration_text": "公式の注記によれば、速度は多様なプロンプト集合に対する平均で、batch sizeは1、デコードはgreedy decodingで測定されています。RTXでの測定にはllama.cpp、AppleのM4 MaxとM5 Maxの測定にはExecuTorchが使われました。つまり、同じモデル名でも、推論エンジン、プロンプト、並列数、生成設定が変われば結果は変わります。74.9から233.4 tok/sという値を、別のGPUや別の実行方式へそのまま当てはめることはできません。",
          "audio": "audio/dlg_003_03_female.mp3",
          "duration_sec": 35.76
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "速さは対話や試作の体験を左右しますが、正確さ、再現性、コストとは別の評価軸です。",
          "naration_text": "生成速度が高ければ、長い推論やツール呼び出しを含む試作で、待ち時間を減らせる可能性があります。それでも、速い出力が正しい出力とは限りません。ツール呼び出しの正確さ、画像を含む入力の解釈、失敗時の挙動、同じ条件で再現できるか、運用に必要な電力や管理コストなどは別の評価軸です。まずは自分の代表的なタスクで速度と品質を同時に測り、導入の判断材料を増やすのがよいでしょう。結果を記録して比較することも有効です。",
          "audio": "audio/dlg_003_04_male.mp3",
          "duration_sec": 30.816
        }
      ],
      "duration_sec": 126.744
    },
    {
      "id": "scene_004",
      "title": "活用の意義 — ローカルでのエージェント試作",
      "accent": "#2d9a9a",
      "accent_soft": "rgba(45, 154, 154, 0.18)",
      "kicker": "PRACTICAL POSSIBILITY",
      "headline": "画像とツールを結び\nローカルで反復する試作へ",
      "lead": "公開された性質から考えられる、開発環境での検証と再利用の可能性を整理します。",
      "image": "images/scene_004.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "画像理解、ツール利用、ローカル実行を想定した設計から、ローカル環境でのエージェント試作が考えられる。",
      "factual_bullets": [
        "テキストと画像の入力",
        "ツール利用を想定",
        "ローカルのエージェントワークフロー向け最適化",
        "公開ウェイト"
      ],
      "forbidden_elements": [
        "開発現場が必ず効率化するという断定",
        "ローカル実行がデータ保護を自動保証するという表現"
      ],
      "image_prompt": "Developer safely prototyping a local multimodal agent: reviewing a screenshot and document, connecting controlled tool cards, iterative loop on a personal workstation, teal blue editorial technology art, no text.",
      "dialogue": [
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "画像を含む入力とツール利用を組み合わせ、手元の環境で小さく試す余地が広がります。",
          "naration_text": "Muse Glimmerは、テキストと画像を組み合わせた入力と、ツール利用を意識した能力を掲げています。これを公開ウェイトとローカル実行の選択肢と組み合わせれば、画面や資料を読み取り、限定したツールを呼ぶエージェントを、自分の環境で小さく試す方向性が考えられます。たとえば、画面の確認、文書の整理、開発補助といった作業で、入力、権限、出力を一つずつ確かめながら試作を重ねる使い方です。これは期待される活用であり、公式が個別用途の成功を保証するものではありません。",
          "audio": "audio/dlg_004_01_female.mp3",
          "duration_sec": 35.04
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "公開ウェイトなら、モデル本体と周辺ツールの組み合わせを用途に合わせて検討できます。",
          "naration_text": "公開ウェイトの利点の一つは、モデルと周辺の仕組みを、自分たちの目的に合わせて組み合わせる検討ができることです。Metaはllama.cpp、MLX、ExecuTorchなどの最適化された統合を案内しています。こうした実行基盤、ツールの呼び出し方、ログの残し方、確認画面などを分けて設計すれば、どの構成が自分たちの作業に合うかを比べやすくなります。ただし、実装の容易さや利用できる統合は変化し得るので、導入時点の公式ドキュメントを確認してください。",
          "audio": "audio/dlg_004_02_male.mp3",
          "duration_sec": 30.456
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "反復しやすさは魅力ですが、入出力の記録と人による確認を最初から組み込むことが重要です。",
          "naration_text": "ローカルで試作を繰り返せるとしても、エージェントに任せる範囲は慎重に決める必要があります。特に外部ツールを使う場合は、読み取り専用から始める、実行前に確認を求める、入力と出力を記録する、失敗時に止める、といった設計が重要です。便利なモデルを導入することと、安全な業務フローを作ることは別の仕事です。小さな検証を通じて、どの作業を支援に任せ、どこを人が判断するかを明確にすることが活用の土台になります。",
          "audio": "audio/dlg_004_03_female.mp3",
          "duration_sec": 31.728
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "価値は完全自動化ではなく、試作と検証を自分の条件で回せる選択肢にあります。順に見極めます。",
          "naration_text": "この発表の技術的な意義は、すべてのエージェント作業を自動化することではありません。マルチモーダルな入力、ツール利用、ローカル実行、量子化、高速化という要素を、公開モデルとして組み合わせて検証しやすくする点にあります。自分のデータ、ハードウェア、業務手順、品質基準に合わせ、比較しながら使い方を探せる可能性があります。実効性能や運用負荷を測り、役に立つ範囲を見つけることが、堅実な導入につながります。小さく始める姿勢が役立ちます。",
          "audio": "audio/dlg_004_04_male.mp3",
          "duration_sec": 31.08
        }
      ],
      "duration_sec": 128.304
    },
    {
      "id": "scene_005",
      "title": "事実と未確認事項 — 導入前に見るべきこと",
      "accent": "#bd6f83",
      "accent_soft": "rgba(189, 111, 131, 0.18)",
      "kicker": "FACTS & OPEN QUESTIONS",
      "headline": "公開情報の先にある\n品質・安定性・条件を検証する",
      "lead": "公式資料の記載と、利用環境ごとに確かめる必要がある事項を明確に区別します。",
      "image": "images/scene_005.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "公式資料はモデルの構成とベンチマークを示すが、全環境・全タスクでの性能、運用条件、独立検証は別途必要。",
      "factual_bullets": [
        "公開日、ライセンス、規模、量子化、DFlash速度は公式資料で確認",
        "実際の品質と速度は環境・タスク依存",
        "安全な運用には追加のガードレールが必要"
      ],
      "forbidden_elements": [
        "公開情報にないメモリ要件や商用条件の断定",
        "第三者検証済みとみなす表現"
      ],
      "image_prompt": "Balanced editorial illustration of verified facts and open questions: checkmarks on one side, thoughtful testing workflow on the other, calm rose and navy palette, no text.",
      "dialogue": [
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "公開資料で確認できるのは、公開形態、規模、量子化、DFlashの公式測定値です。",
          "naration_text": "ここまでに確認した事実は明確です。Metaは2026年8月10日にMuse Glimmerを発表し、公開ウェイトをApache 2.0で提供しました。モデルカードには約29.6Bという規模、テキストと画像の入力、4bit相当の量子化、24GB VRAMを対象とするK-Quant-17GB、DFlashを使うRTX 5090上の速度表が記載されています。これらは公式資料の記述です。その一方で、公式資料はすべての実行条件や利用結果を網羅するものではありません。",
          "audio": "audio/dlg_005_01_female.mp3",
          "duration_sec": 36.192
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "品質や速度が、画像・ツール・長い文脈を含む全タスクで同じになるかは未確認です。用途ごとに検証しましょう。",
          "naration_text": "公式資料だけでは、すべての画像入力、ツール利用タスク、長いコンテキスト、複雑なエージェント作業で、同じ品質や速度が得られるかまでは確認できません。特定のベンチマークや速度測定は有用な手がかりですが、実際の仕事ではデータの癖、ツールの仕様、失敗の扱い、評価基準が異なります。個別のタスクで正確に処理できるか、同じ入力に安定して応答できるかは、導入する側が代表ケースを用意して確認すべき項目です。利用者自身の検証が欠かせません。",
          "audio": "audio/dlg_005_02_male.mp3",
          "duration_sec": 31.104
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "必要メモリ、提供範囲、商用条件、第三者検証は、最新資料と実測を照らして確認します。",
          "naration_text": "利用時の具体的なメモリ要件、利用できる実行基盤や提供範囲、商用利用に関する個別の条件、第三者による独立した検証の状況も、今回の公式発表だけで結論を出せるものではありません。量子化された構成が24GB級GPUを対象にすることと、手元のマシンで余裕を持って運用できることは別です。導入前には最新のモデルカード、配布物、実行基盤の文書を確認し、実際の設定で測定してください。必要に応じて専門家にも相談しましょう。",
          "audio": "audio/dlg_005_03_female.mp3",
          "duration_sec": 34.488
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "ローカル実行でも安全性は自動では保証されず、権限設計と評価を含めた運用が必要です。",
          "naration_text": "ローカルで実行できることは、品質、安全性、プライバシー、法令順守を自動的に保証するものではありません。モデルカードは、用途と文脈に応じて追加のガードレールを備えたシステムとして配備することを推奨しています。外部ツールへの権限、機密情報の扱い、生成内容の確認、ログ、停止手順を設計し、目的に合う評価データで確かめることが必要です。公開モデルの柔軟性を生かすほど、利用者側の検証と責任ある運用が重要になります。",
          "audio": "audio/dlg_005_04_male.mp3",
          "duration_sec": 29.904
        }
      ],
      "duration_sec": 131.688
    },
    {
      "id": "scene_999",
      "title": "まとめ — Muse Glimmer 30B をどう活用するか",
      "accent": "#d17a67",
      "accent_soft": "rgba(209, 122, 103, 0.18)",
      "kicker": "SUMMARY",
      "headline": "公開モデルを正確に読み\nローカルAIの次の試作へ",
      "lead": "確認済みの公開情報を土台に、性能・安全性・利用条件を自分の環境で確かめることが出発点です。",
      "image": "images/scene_999.png",
      "source_documents": [
        "https://research.meta.ai/blog/introducing-muse-glimmer-open-agentic-model",
        "https://huggingface.co/meta-models/Muse-Glimmer-30B"
      ],
      "source_summary": "Muse Glimmer 30Bは、公開ウェイト、ローカル実行、マルチモーダル入力、4bit量子化、DFlash高速化を組み合わせたモデルとして公開された。",
      "factual_bullets": [
        "2026年8月10日発表",
        "Apache 2.0の公開ウェイト",
        "約30Bのマルチモーダル・エージェントモデル",
        "4bit量子化とDFlashによるローカル実行のための最適化"
      ],
      "forbidden_elements": [
        "万能なローカルエージェントという断定",
        "品質・安全性・商用利用条件が確認済みという表現"
      ],
      "image_prompt": "Optimistic Japanese AI news closing frame: a local workstation, a subtle multimodal agent glow, open development paths toward a bright horizon, navy coral and gold editorial illustration, no text or logos.",
      "dialogue": [
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "Muse Glimmer 30Bは、公開ウェイトでローカルのエージェント利用を目指す30B級モデルです。",
          "naration_text": "Metaが公開したMuse Glimmer 30Bは、約30Bの規模、テキストと画像を扱う入力、ツール利用を意識したエージェント向けの設計を備えた公開モデルです。Apache 2.0ライセンスでウェイトが提供され、ローカル実行に向けて4bit相当の量子化とDFlashを使う推論高速化が説明されています。これは、手元の環境でマルチモーダルなエージェントを試作する選択肢を広げる動きとして注目できます。",
          "audio": "audio/dlg_999_01_male.mp3",
          "duration_sec": 25.176
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "RTX 5090の公式測定値は参考になりますが、速度と品質は自分の条件で確かめる必要があります。",
          "naration_text": "DFlashを使ったRTX 5090上の公式測定では、74.9 tok/sから233.4 tok/sへの向上が示されました。ただし、この数値は特定のモデル構成、推論エンジン、batch size、デコード設定で得られた平均です。別のGPU、別の入力、長い文脈、画像やツールを使う作業に同じ結果を約束するものではありません。速度だけでなく、正確さ、再現性、メモリ使用量、運用コストを、実際に使いたいタスクで一緒に確認していきましょう。",
          "audio": "audio/dlg_999_02_female.mp3",
          "duration_sec": 35.856
        },
        {
          "speaker": "male",
          "expression": "neutral",
          "telop_text": "公開情報と未確認事項を分け、小さな検証から使い方を育てることが大切です。確認を重ねましょう。",
          "naration_text": "公開モデルを活用する際は、確認できた事実を土台にしつつ、未確認の点を推測で埋めないことが大切です。長いエージェント作業の安定性、画像を含む実タスクの品質、各環境での速度、必要メモリ、第三者による検証、提供範囲、安全性や商用利用条件は、最新資料と実測で確かめましょう。権限を絞った小さな試作から始め、結果を比べながら自分の作業に合う範囲を探すことが、前向きで安全な活用につながります。その積み重ねが、納得できる活用につながります。",
          "audio": "audio/dlg_999_03_male.mp3",
          "duration_sec": 33.168
        },
        {
          "speaker": "female",
          "expression": "neutral",
          "telop_text": "AiDiyで最新AIニュースを楽しく学び、次の解説ビデオも一緒に作っていきましょう。",
          "naration_text": "この動画は AiDiy のニュース版ビデオ生成機能で自動生成されました。内容が参考になったら、ぜひチャンネル登録をお願いします。自分でも AiDiy で最新AIニュースの解説ビデオを作ってみて、公式情報を確かめながら、あなたならではの視点を届けてください。新しい技術を楽しく前向きに学び、小さな試作から次の発見へ進んでいきましょう。気になったテーマから、無理なく始めてみてください。これからも一緒に楽しみましょう。",
          "audio": "audio/dlg_999_04_female.mp3",
          "duration_sec": 30.552
        }
      ],
      "duration_sec": 124.752
    }
  ],
  "total_duration_sec": 875.616
};
